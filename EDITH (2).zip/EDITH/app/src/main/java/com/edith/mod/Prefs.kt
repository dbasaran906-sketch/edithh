package com.edith.mod

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(ctx: Context) {
        if (sp == null) {
            sp = ctx.applicationContext.getSharedPreferences("edith_prefs", Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences = sp ?: error("Prefs.init çağrılmadı")

    private val defaults = mapOf(
        Gesture.ONE to Command.OPEN_APP,
        Gesture.TWO to Command.OPEN_CAMERA,
        Gesture.THREE to Command.VOLUME_UP,
        Gesture.FOUR to Command.VOLUME_DOWN,
        Gesture.FIVE to Command.GO_HOME,
        Gesture.FIST to Command.LOCK_SCREEN,
        Gesture.THUMB_UP to Command.MEDIA_PLAY_PAUSE,
        Gesture.THUMB_DOWN to Command.GO_BACK,
        Gesture.OK to Command.SCREENSHOT,
        Gesture.ROCK to Command.FLASHLIGHT,
        Gesture.CALL to Command.OPEN_DIALER,
        Gesture.LOVE to Command.OPEN_ASSISTANT
    )

    /** Algılama süresi (ms): 400 - 3000 */
    var holdMs: Int
        get() = p().getInt("holdMs", 800)
        set(v) = p().edit().putInt("holdMs", v.coerceIn(400, 3000)).apply()

    /** 0 = katı, 1 = çok kolay */
    var sensitivity: Float
        get() = p().getFloat("sensitivity", 0.6f)
        set(v) = p().edit().putFloat("sensitivity", v.coerceIn(0f, 1f)).apply()

    var vibrate: Boolean
        get() = p().getBoolean("vibrate", true)
        set(v) = p().edit().putBoolean("vibrate", v).apply()

    var sound: Boolean
        get() = p().getBoolean("sound", true)
        set(v) = p().edit().putBoolean("sound", v).apply()

    /** EDITH kapalıyken bildirimde "dokun, aktif et" göster. */
    var idleNotification: Boolean
        get() = p().getBoolean("idleNotification", true)
        set(v) = p().edit().putBoolean("idleNotification", v).apply()

    fun getCommand(g: Gesture): Command {
        val name = p().getString("cmd_${g.name}", null)
        return Command.values().firstOrNull { it.name == name } ?: defaults[g] ?: Command.NONE
    }

    fun setCommand(g: Gesture, c: Command) {
        p().edit().putString("cmd_${g.name}", c.name).apply()
    }

    fun getAppPackage(g: Gesture): String = p().getString("app_${g.name}", "") ?: ""

    fun getAppLabel(g: Gesture): String = p().getString("applabel_${g.name}", "") ?: ""

    fun setApp(g: Gesture, pkg: String, label: String) {
        p().edit().putString("app_${g.name}", pkg).putString("applabel_${g.name}", label).apply()
    }
}
