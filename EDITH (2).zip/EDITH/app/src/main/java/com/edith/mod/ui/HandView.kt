package com.edith.mod.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

private val BONES = listOf(
    0 to 1, 1 to 2, 2 to 3, 3 to 4,
    0 to 5, 5 to 6, 6 to 7, 7 to 8,
    5 to 9, 9 to 10, 10 to 11, 11 to 12,
    9 to 13, 13 to 14, 14 to 15, 15 to 16,
    13 to 17, 17 to 18, 18 to 19, 19 to 20,
    0 to 17
)

private val TIPS = setOf(4, 8, 12, 16, 20)
private val PALM = listOf(0, 1, 5, 9, 13, 17)

/**
 * Elin kemik (röntgen) görünümü. Noktalar çizim aşamasında okunur,
 * bu yüzden her kare yalnızca bu tuval yeniden çizilir.
 */
@Composable
fun HandView(hand: State<FloatArray?>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val pts = hand.value ?: return@Canvas
        if (pts.size < 42) return@Canvas

        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (i in 0 until 21) {
            val x = pts[2 * i]
            val y = pts[2 * i + 1]
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
        }
        val w = (maxX - minX).coerceAtLeast(0.01f)
        val h = (maxY - minY).coerceAtLeast(0.01f)
        val scale = (size.minDimension * 0.82f) / maxOf(w, h)
        val ox = size.width / 2f - (minX + w / 2f) * scale
        val oy = size.height / 2f - (minY + h / 2f) * scale

        fun p(i: Int) = Offset(ox + pts[2 * i] * scale, oy + pts[2 * i + 1] * scale)

        // Avuç içi: çok hafif dolgu
        val palm = Path()
        PALM.forEachIndexed { k, i ->
            val o = p(i)
            if (k == 0) palm.moveTo(o.x, o.y) else palm.lineTo(o.x, o.y)
        }
        palm.close()
        drawPath(palm, Color.White.copy(alpha = 0.07f))

        // Kemikler: yumuşak parıltı + ince çekirdek
        for ((a, b) in BONES) {
            drawLine(
                color = Color.White.copy(alpha = 0.14f),
                start = p(a),
                end = p(b),
                strokeWidth = 8.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
        for ((a, b) in BONES) {
            drawLine(
                color = Color.White.copy(alpha = 0.92f),
                start = p(a),
                end = p(b),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        // Eklemler: içi boş halka, parmak uçları dolu
        for (i in 0 until 21) {
            val o = p(i)
            if (i in TIPS) {
                drawCircle(color = Color.White, radius = 4.5.dp.toPx(), center = o)
            } else {
                drawCircle(color = Color.Black, radius = 3.6.dp.toPx(), center = o)
                drawCircle(
                    color = Color.White.copy(alpha = 0.95f),
                    radius = 3.6.dp.toPx(),
                    center = o,
                    style = Stroke(1.4.dp.toPx())
                )
            }
        }
    }
}
