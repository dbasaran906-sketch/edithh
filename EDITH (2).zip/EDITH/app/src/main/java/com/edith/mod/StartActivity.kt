package com.edith.mod

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat

/** Bildirime dokununca görünmeden EDITH'i başlatır. */
class StartActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)

        if (Perms.camera(this)) {
            if (!EdithState.running.value) {
                ContextCompat.startForegroundService(this, Intent(this, EdithService::class.java))
            }
        } else {
            CommandExecutor.toast(this, "Önce kamera iznini ver")
            startActivity(Intent(this, MainActivity::class.java))
        }

        // Servis kamerayı açana kadar ön planda kalsın
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 700)
    }
}
