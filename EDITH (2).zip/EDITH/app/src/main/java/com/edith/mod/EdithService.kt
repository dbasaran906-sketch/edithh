package com.edith.mod

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class EdithService : LifecycleService() {

    private val main = Handler(Looper.getMainLooper())
    private var landmarker: HandLandmarker? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var executor: ExecutorService? = null
    private var started = false

    // Yalnızca analiz iş parçacığında kullanılır
    private var lastAnalyzed = 0L
    private var handMiss = 0
    private var prevPts: FloatArray? = null
    private var lastProgress = -1f
    private var candidate: Gesture? = null
    private var candidateSince = 0L
    private var miss = 0
    private var fired = false

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        executor = Executors.newSingleThreadExecutor { r ->
            Thread(r, "edith-analyzer").apply { priority = Thread.NORM_PRIORITY - 2 }
        }
        Notifier.ensureChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (started) return START_NOT_STICKY
        started = true

        startAsForeground()
        Notifier.hideIdle(this)

        if (!initLandmarker()) {
            CommandExecutor.toast(this, "EDITH: el modeli yüklenemedi")
            stopSelf()
            return START_NOT_STICKY
        }
        startCamera()
        EdithState.running.value = true
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        return super.onBind(intent)
    }

    // ---------------------------------------------------------------- ön plan

    private fun startAsForeground() {
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, EdithService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, Notifier.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_edith)
            .setContentTitle("EDITH aktif")
            .setContentText("Ön kamera hareketleri dinleniyor")
            .setContentIntent(openPi)
            .addAction(0, "Durdur", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= 30) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------ model/kamera

    private fun initLandmarker(): Boolean {
        return try {
            val base = BaseOptions.builder().setModelAssetPath(MODEL_FILE).build()
            val opts = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setRunningMode(RunningMode.IMAGE)
                .build()
            landmarker = HandLandmarker.createFromOptions(this, opts)
            true
        } catch (t: Throwable) {
            false
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider

                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(640, 480))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor!!) { proxy -> analyze(proxy) }

                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                CommandExecutor.toast(this, "EDITH: ön kamera açılamadı")
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            // Saniyede en fazla ~15 kare işle: telefon kasmasın
            val t0 = SystemClock.elapsedRealtime()
            if (t0 - lastAnalyzed < MIN_INTERVAL_MS) return
            lastAnalyzed = t0

            val lm = landmarker ?: return
            val raw = proxy.toBitmap()
            val rot = proxy.imageInfo.rotationDegrees
            val bmp: Bitmap = if (rot != 0) {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            } else {
                raw
            }
            val aspect = bmp.width.toFloat() / bmp.height.toFloat()
            val result = lm.detect(BitmapImageBuilder(bmp).build())
            val hand = result.landmarks().firstOrNull()

            if (hand != null) {
                handMiss = 0
                publishHand(hand, aspect)
            } else {
                handMiss++
                if (handMiss >= 4) {
                    prevPts = null
                    EdithState.hand.value = null
                }
            }

            val g = if (hand != null) GestureClassifier.classify(hand, aspect, Prefs.sensitivity) else null
            onFrame(g)
        } catch (t: Throwable) {
            // tek kare hatası önemsiz
        } finally {
            proxy.close()
        }
    }

    /** Noktaları aynala, yumuşat ve arayüze gönder. */
    private fun publishHand(hand: List<NormalizedLandmark>, aspect: Float) {
        val n = hand.size.coerceAtMost(21)
        val out = FloatArray(n * 2)
        val prev = prevPts
        for (i in 0 until n) {
            val x = (1f - hand[i].x()) * aspect
            val y = hand[i].y()
            if (prev != null && prev.size == out.size) {
                out[2 * i] = prev[2 * i] + (x - prev[2 * i]) * 0.65f
                out[2 * i + 1] = prev[2 * i + 1] + (y - prev[2 * i + 1]) * 0.65f
            } else {
                out[2 * i] = x
                out[2 * i + 1] = y
            }
        }
        prevPts = out
        EdithState.hand.value = out
    }

    // ------------------------------------------------------------ hareket takibi

    private fun setProgress(p: Float) {
        if (p == 0f || p == 1f || abs(p - lastProgress) >= 0.04f) {
            lastProgress = p
            EdithState.holdProgress.value = p
        }
    }

    private fun onFrame(g: Gesture?) {
        val now = SystemClock.elapsedRealtime()

        if (g == candidate) {
            miss = 0
        } else {
            miss++
            if (candidate == null || miss >= 3) {
                candidate = g
                candidateSince = now
                miss = 0
                fired = false
                setProgress(0f)
            }
        }

        val c = candidate
        EdithState.liveGesture.value = c
        if (c == null) {
            setProgress(0f)
            return
        }
        if (fired) return

        val hold = Prefs.holdMs
        val held = now - candidateSince
        setProgress((held.toFloat() / hold).coerceIn(0f, 1f))
        if (held >= hold) {
            fired = true
            setProgress(1f)
            main.post { trigger(c) }
        }
    }

    private fun trigger(g: Gesture) {
        val cmd = Prefs.getCommand(g)
        if (cmd == Command.NONE) return

        val label = if (cmd == Command.OPEN_APP && Prefs.getAppLabel(g).isNotBlank()) {
            Prefs.getAppLabel(g)
        } else {
            cmd.label
        }
        EdithState.lastAction.value = "${g.emoji}  ${g.label}  ›  $label"

        if (Prefs.vibrate) buzz()
        if (Prefs.sound) chime()

        CommandExecutor.execute(this, g, cmd)
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            v.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
            // titreşim yoksa geç
        }
    }

    private fun chime() {
        try {
            val t = ToneGenerator(AudioManager.STREAM_SYSTEM, 35)
            t.startTone(ToneGenerator.TONE_PROP_ACK, 120)
            main.postDelayed({ t.release() }, 400)
        } catch (e: Exception) {
            // ses yoksa geç
        }
    }

    // ----------------------------------------------------------------- bitiş

    override fun onDestroy() {
        try {
            cameraProvider?.unbindAll()
        } catch (e: Exception) {
            // yok say
        }
        executor?.shutdown()
        try {
            executor?.awaitTermination(500, TimeUnit.MILLISECONDS)
        } catch (e: Exception) {
            // yok say
        }
        try {
            landmarker?.close()
        } catch (t: Throwable) {
            // yok say
        }
        landmarker = null
        EdithState.running.value = false
        EdithState.liveGesture.value = null
        EdithState.holdProgress.value = 0f
        EdithState.hand.value = null
        Notifier.showIdle(applicationContext)
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.edith.mod.STOP"
        private const val NOTIF_ID = 1
        private const val MODEL_FILE = "hand_landmarker.task"
        private const val MIN_INTERVAL_MS = 66L
    }
}
