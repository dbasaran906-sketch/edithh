package com.edith.mod

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.edith.mod.ui.BottomBar
import com.edith.mod.ui.EdithTheme
import com.edith.mod.ui.GemBackground
import com.edith.mod.ui.GesturesScreen
import com.edith.mod.ui.HomeScreen
import com.edith.mod.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        if (!EdithState.running.value) Notifier.showIdle(this)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            EdithTheme {
                EdithRoot()
            }
        }
    }
}

private fun startEdith(ctx: Context) {
    ContextCompat.startForegroundService(ctx, Intent(ctx, EdithService::class.java))
}

private fun stopEdith(ctx: Context) {
    ctx.stopService(Intent(ctx, EdithService::class.java))
}

@Composable
fun EdithRoot() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && !EdithState.running.value) Notifier.showIdle(ctx)
    }
    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            startEdith(ctx)
            if (!Perms.notifications(ctx) && Build.VERSION.SDK_INT >= 33) {
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val onToggle: () -> Unit = {
        if (EdithState.running.value) {
            stopEdith(ctx)
        } else if (!Perms.camera(ctx)) {
            camLauncher.launch(Manifest.permission.CAMERA)
        } else {
            startEdith(ctx)
        }
    }

    Box(Modifier.fillMaxSize()) {
        GemBackground()
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen(onToggle)
                    1 -> GesturesScreen()
                    else -> SettingsScreen()
                }
            }
            BottomBar(selected = tab, onSelect = { tab = it })
        }
    }
}
