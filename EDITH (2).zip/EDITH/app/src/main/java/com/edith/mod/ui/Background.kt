package com.edith.mod.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.sin
import kotlin.random.Random

/**
 * Siyah zemin üzerinde çok küçük, yuvarlak kristal taş deseni + hafif parıltılar.
 * Taşlar ve karartma tek bitmap'e bir kez çizilir; her karede yalnızca o bitmap
 * ve birkaç parıltı çizilir (telefon kasmasın diye).
 */
@Composable
fun GemBackground() {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(
            Modifier.fillMaxSize().drawWithCache {
                val w = size.width.toInt().coerceAtLeast(1)
                val h = size.height.toInt().coerceAtLeast(1)
                val bmp = ImageBitmap(w, h)
                CanvasDrawScope().draw(
                    this,
                    layoutDirection,
                    androidx.compose.ui.graphics.Canvas(bmp),
                    size
                ) {
                    drawStones()
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(Color(0x99000000), Color(0x22000000), Color(0x99000000))
                        )
                    )
                }
                onDrawBehind { drawImage(bmp) }
            }
        )
        Sparkles()
    }
}

private fun DrawScope.drawStones() {
    val step = 10.dp.toPx()
    val r = 3.3.dp.toPx()
    val rowH = step * 0.866f
    val hi = 0.8.dp.toPx()
    val ring = 0.5.dp.toPx()

    var y = 0f
    var row = 0
    while (y < size.height + step) {
        var x = if (row % 2 == 0) 0f else step / 2f
        while (x < size.width + step) {
            drawCircle(color = Color(0xFF1B1B1B), radius = r, center = Offset(x, y))
            drawCircle(color = Color(0x1AFFFFFF), radius = r, center = Offset(x, y), style = Stroke(ring))
            drawCircle(
                color = Color(0x52FFFFFF),
                radius = hi,
                center = Offset(x - r * 0.35f, y - r * 0.35f)
            )
            x += step
        }
        y += rowH
        row++
    }
}

@Composable
private fun Sparkles() {
    val inf = rememberInfiniteTransition(label = "sparkles")
    val t by inf.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart),
        label = "t"
    )
    val spots = remember {
        List(12) { i ->
            Triple(
                Random(i * 7 + 3).nextFloat(),
                Random(i * 13 + 5).nextFloat(),
                Random(i * 17 + 1).nextFloat()
            )
        }
    }
    Canvas(Modifier.fillMaxSize()) {
        for ((fx, fy, ph) in spots) {
            val s = sin((t + ph) * 6.2831855f).coerceAtLeast(0f)
            val a = s * s * s * s * s * s
            if (a > 0.03f) {
                val c = Offset(fx * size.width, fy * size.height)
                val len = 7.dp.toPx() * (0.5f + a)
                val col = Color.White.copy(alpha = a)
                drawLine(col, Offset(c.x - len, c.y), Offset(c.x + len, c.y), strokeWidth = 1.dp.toPx())
                drawLine(col, Offset(c.x, c.y - len), Offset(c.x, c.y + len), strokeWidth = 1.dp.toPx())
                drawCircle(color = col, radius = 1.4.dp.toPx(), center = c)
            }
        }
    }
}
