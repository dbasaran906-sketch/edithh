package com.edith.mod

import kotlinx.coroutines.flow.MutableStateFlow

/** Servis ile arayüz arasındaki canlı durum. */
object EdithState {
    val running = MutableStateFlow(false)
    val liveGesture = MutableStateFlow<Gesture?>(null)
    val holdProgress = MutableStateFlow(0f)
    val lastAction = MutableStateFlow("")

    /** 21 el noktası: [x0, y0, x1, y1, ...]. Aynalanmış ve düzleştirilmiş. El yoksa null. */
    val hand = MutableStateFlow<FloatArray?>(null)
}
