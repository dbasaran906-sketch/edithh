package com.edith.mod

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

object Notifier {
    const val CHANNEL_ID = "edith_channel"
    private const val IDLE_ID = 2

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL_ID, "EDITH", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    /** EDITH kapalıyken görünen "dokun, aktif et" bildirimi. */
    fun showIdle(ctx: Context) {
        if (!Prefs.idleNotification || !Perms.notifications(ctx)) return
        ensureChannel(ctx)
        val pi = PendingIntent.getActivity(
            ctx, 2,
            Intent(ctx, StartActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_edith)
            .setContentTitle("EDITH hazır")
            .setContentText("Dokun, hareket modunu aktif et")
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(IDLE_ID, n)
    }

    fun hideIdle(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(IDLE_ID)
    }
}
