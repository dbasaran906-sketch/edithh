package com.edith.mod.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edith.mod.EdithState
import com.edith.mod.Perms
import com.edith.mod.Prefs
import com.edith.mod.R

@Composable
fun HomeScreen(onToggle: () -> Unit) {
    val ctx = LocalContext.current
    val running by EdithState.running.collectAsState()
    val live by EdithState.liveGesture.collectAsState()
    val progress by EdithState.holdProgress.collectAsState()
    val last by EdithState.lastAction.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Image(
            painter = painterResource(R.drawable.edith_logo),
            contentDescription = null,
            modifier = Modifier
                .size(84.dp)
                .clip(CircleShape)
                .border(1.dp, Color(0x66FFFFFF), CircleShape),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.height(14.dp))
        Text(
            "EDITH",
            color = Color.White,
            fontSize = 36.sp,
            fontWeight = FontWeight.ExtraLight,
            letterSpacing = 14.sp
        )
        Text(
            "HAREKET KONTROL MODU",
            color = EdithColors.Steel,
            fontSize = 11.sp,
            letterSpacing = 4.sp
        )

        Spacer(Modifier.height(34.dp))
        PowerButton(active = running, onClick = onToggle)
        Spacer(Modifier.height(16.dp))
        Text(
            if (running) "AKTİF" else "KAPALI",
            color = if (running) Color.White else EdithColors.Dim,
            fontSize = 13.sp,
            letterSpacing = 6.sp,
            fontWeight = FontWeight.Medium
        )

        Spacer(Modifier.height(26.dp))
        EdithCard {
            SectionLabel("CANLI ALGILAMA")
            Spacer(Modifier.height(12.dp))
            if (running) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(live?.emoji ?: "…", fontSize = 38.sp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(
                            live?.label ?: "El bekleniyor",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Medium
                        )
                        val g = live
                        Text(
                            if (g != null) Prefs.getCommand(g).label else "Elini ön kameraya göster",
                            color = EdithColors.Steel,
                            fontSize = 13.sp
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = Color.White,
                    trackColor = Color(0x26FFFFFF)
                )
            } else {
                Text(
                    "Başlatmak için tuşa dokun. Kamera yalnızca EDITH aktifken çalışır.",
                    color = EdithColors.Steel,
                    fontSize = 14.sp
                )
            }
        }

        if (last.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            EdithCard {
                SectionLabel("SON KOMUT")
                Spacer(Modifier.height(8.dp))
                Text(last, color = Color.White, fontSize = 15.sp)
            }
        }

        if (!Perms.overlay(ctx)) {
            Spacer(Modifier.height(12.dp))
            EdithCard {
                SectionLabel("KURULUM")
                Spacer(Modifier.height(8.dp))
                Text(
                    "Uygulama açma komutlarının arka planda çalışması için Ayarlar › İzinler bölümünden " +
                        "\"Diğer uygulamaların üstünde göster\" iznini ver.",
                    color = EdithColors.Steel,
                    fontSize = 13.sp
                )
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}
