package com.edith.mod.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.edith.mod.Perms
import com.edith.mod.Prefs

@Composable
fun SettingsScreen() {
    var hold by remember { mutableFloatStateOf(Prefs.holdMs.toFloat()) }
    var sens by remember { mutableFloatStateOf(Prefs.sensitivity) }
    var vibrate by remember { mutableStateOf(Prefs.vibrate) }
    var sound by remember { mutableStateOf(Prefs.sound) }
    var glow by remember { mutableStateOf(Prefs.glow) }

    val sliderColors = SliderDefaults.colors(
        thumbColor = Color.White,
        activeTrackColor = Color.White,
        inactiveTrackColor = Color(0x33FFFFFF),
        activeTickColor = Color.Transparent,
        inactiveTickColor = Color.Transparent
    )

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        ScreenTitle("AYARLAR", "Hassasiyet, geri bildirim ve izinler")
        Spacer(Modifier.height(18.dp))

        EdithCard {
            SectionLabel("ALGILAMA SÜRESİ")
            Spacer(Modifier.height(6.dp))
            Text(
                "%.1f saniye".format(hold / 1000f),
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Light
            )
            Text(
                "Hareketi bu kadar süre tutunca komut çalışır (0,4 - 3,0 sn).",
                color = EdithColors.Steel,
                fontSize = 12.sp
            )
            Slider(
                value = hold,
                onValueChange = {
                    hold = it
                    Prefs.holdMs = it.toInt()
                },
                valueRange = 400f..3000f,
                steps = 25,
                colors = sliderColors
            )
        }

        Spacer(Modifier.height(12.dp))
        EdithCard {
            SectionLabel("HASSASİYET")
            Spacer(Modifier.height(6.dp))
            Text(
                "%d%%".format((sens * 100).toInt()),
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Light
            )
            Text(
                "Yüksek: kusursuz poz gerekmez, kolay algılar. Düşük: yalnızca net hareketler.",
                color = EdithColors.Steel,
                fontSize = 12.sp
            )
            Slider(
                value = sens,
                onValueChange = {
                    sens = it
                    Prefs.sensitivity = it
                },
                valueRange = 0f..1f,
                colors = sliderColors
            )
        }

        Spacer(Modifier.height(12.dp))
        EdithCard {
            SectionLabel("GERİ BİLDİRİM")
            SwitchRow("Titreşim", "Komut çalışınca hafif titrer", vibrate) {
                vibrate = it
                Prefs.vibrate = it
            }
            SwitchRow("Ses", "İnce bir onay sesi çalar", sound) {
                sound = it
                Prefs.sound = it
            }
            SwitchRow("Ekran parıltısı", "Üstte kısa bir bilgi kapsülü gösterir", glow) {
                glow = it
                Prefs.glow = it
            }
        }

        Spacer(Modifier.height(12.dp))
        PermissionsCard()

        Spacer(Modifier.height(12.dp))
        EdithCard {
            SectionLabel("HAKKINDA")
            Spacer(Modifier.height(8.dp))
            Text("EDITH 1.0", color = Color.White, fontSize = 15.sp)
            Text(
                "Kamera görüntüsü kaydedilmez, telefondan dışarı çıkmaz. Ekran kilitliyken ön kamera çalışmaz (Android kısıtı).",
                color = EdithColors.Steel,
                fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(desc, color = EdithColors.Steel, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = Color.White,
                checkedBorderColor = Color.White,
                uncheckedThumbColor = Color(0xFF9A9A9A),
                uncheckedTrackColor = Color(0xFF1A1A1A),
                uncheckedBorderColor = Color(0x55FFFFFF)
            )
        )
    }
}

@Composable
private fun PermissionsCard() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) tick++
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val cam = remember(tick) { Perms.camera(ctx) }
    val overlay = remember(tick) { Perms.overlay(ctx) }
    val a11y = remember(tick) { Perms.accessibility(ctx) }
    val write = remember(tick) { Perms.writeSettings(ctx) }
    val notif = remember(tick) { Perms.notifications(ctx) }

    val pkgUri = Uri.parse("package:${ctx.packageName}")

    EdithCard {
        SectionLabel("İZİNLER")
        PermRow("Kamera", "Ön kamerayla el hareketi algılamak için", cam) {
            camLauncher.launch(Manifest.permission.CAMERA)
        }
        PermRow("Diğer uygulamaların üstünde göster", "Uygulama açma ve parıltı için", overlay) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri))
        }
        PermRow("Erişilebilirlik", "Ana ekran, geri, kilit, ekran görüntüsü, kaydırma için", a11y) {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        PermRow("Sistem ayarlarını değiştir", "Parlaklık komutları için", write) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            PermRow("Bildirimler", "Aktif durumunu bildirimde göstermek için", notif) {
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}

@Composable
private fun PermRow(title: String, desc: String, granted: Boolean, onGrant: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(desc, color = EdithColors.Steel, fontSize = 12.sp)
        }
        if (granted) {
            Text("●  VERİLDİ", color = Color.White, fontSize = 11.sp, letterSpacing = 2.sp)
        } else {
            OutlinedButton(
                onClick = onGrant,
                border = BorderStroke(1.dp, Color(0x66FFFFFF)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Text("VER", fontSize = 12.sp, letterSpacing = 2.sp)
            }
        }
    }
}
