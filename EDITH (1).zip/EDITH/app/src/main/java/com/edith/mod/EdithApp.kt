package com.edith.mod

import android.app.Application

class EdithApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}
