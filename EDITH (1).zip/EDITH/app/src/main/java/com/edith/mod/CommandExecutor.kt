package com.edith.mod

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast

object CommandExecutor {

    private var torchOn = false

    fun toast(ctx: Context, msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    fun execute(ctx: Context, g: Gesture, c: Command) {
        try {
            perform(ctx, g, c)
        } catch (e: Exception) {
            toast(ctx, "Komut çalışmadı: ${c.label}")
        }
    }

    private fun launch(ctx: Context, intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    }

    private fun a11y(ctx: Context, block: (EdithAccessibilityService) -> Unit) {
        val s = EdithAccessibilityService.instance
        if (s == null) {
            toast(ctx, "Erişilebilirlik izni gerekli (Ayarlar › İzinler)")
        } else {
            block(s)
        }
    }

    private fun perform(ctx: Context, g: Gesture, c: Command) {
        when (c) {
            Command.NONE -> Unit

            Command.OPEN_APP -> {
                val pkg = Prefs.getAppPackage(g)
                if (pkg.isBlank()) {
                    toast(ctx, "Bu hareket için uygulama seçilmedi")
                } else {
                    val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
                    if (i == null) toast(ctx, "Uygulama bulunamadı") else launch(ctx, i)
                }
            }

            Command.OPEN_CAMERA -> launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            Command.OPEN_DIALER -> launch(ctx, Intent(Intent.ACTION_DIAL))
            Command.OPEN_CLOCK -> launch(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS))
            Command.OPEN_SETTINGS -> launch(ctx, Intent(Settings.ACTION_SETTINGS))
            Command.OPEN_GOOGLE -> launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))

            Command.OPEN_ASSISTANT -> {
                val tries = listOf(
                    Intent("android.intent.action.VOICE_ASSIST"),
                    Intent(Intent.ACTION_ASSIST),
                    Intent(Intent.ACTION_VOICE_COMMAND)
                )
                var done = false
                for (i in tries) {
                    if (done) break
                    try {
                        launch(ctx, i)
                        done = true
                    } catch (e: Exception) {
                        // sıradakini dene
                    }
                }
                if (!done) toast(ctx, "Sesli asistan bulunamadı")
            }

            Command.OPEN_INTERNET_PANEL -> {
                if (Build.VERSION.SDK_INT >= 29) {
                    launch(ctx, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                } else {
                    launch(ctx, Intent(Settings.ACTION_WIFI_SETTINGS))
                }
            }

            Command.FLASHLIGHT -> {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull {
                    val ch = cm.getCameraCharacteristics(it)
                    ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                        ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                }
                if (id == null) {
                    toast(ctx, "Fener bulunamadı")
                } else {
                    torchOn = !torchOn
                    cm.setTorchMode(id, torchOn)
                }
            }

            Command.VOLUME_UP -> audio(ctx).adjustStreamVolume(
                AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI
            )
            Command.VOLUME_DOWN -> audio(ctx).adjustStreamVolume(
                AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI
            )
            Command.MUTE -> audio(ctx).adjustStreamVolume(
                AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI
            )

            Command.BRIGHTNESS_UP -> brightness(ctx, +40)
            Command.BRIGHTNESS_DOWN -> brightness(ctx, -40)

            Command.MEDIA_PLAY_PAUSE -> mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            Command.MEDIA_NEXT -> mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT)
            Command.MEDIA_PREVIOUS -> mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS)

            Command.GO_HOME -> a11y(ctx) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) }
            Command.GO_BACK -> a11y(ctx) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }
            Command.RECENTS -> a11y(ctx) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) }
            Command.NOTIFICATIONS -> a11y(ctx) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) }
            Command.QUICK_SETTINGS -> a11y(ctx) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) }
            Command.POWER_MENU -> a11y(ctx) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG) }
            Command.LOCK_SCREEN -> a11y(ctx) {
                if (Build.VERSION.SDK_INT >= 28) {
                    it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                } else {
                    toast(ctx, "Ekran kilidi için Android 9 veya üstü gerekir")
                }
            }
            Command.SCREENSHOT -> a11y(ctx) {
                if (Build.VERSION.SDK_INT >= 28) {
                    it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
                } else {
                    toast(ctx, "Ekran görüntüsü için Android 9 veya üstü gerekir")
                }
            }

            Command.SCROLL_DOWN -> a11y(ctx) { it.swipe(0.5f, 0.72f, 0.5f, 0.28f) }
            Command.SCROLL_UP -> a11y(ctx) { it.swipe(0.5f, 0.28f, 0.5f, 0.72f) }
            Command.SWIPE_LEFT -> a11y(ctx) { it.swipe(0.8f, 0.5f, 0.2f, 0.5f) }
            Command.SWIPE_RIGHT -> a11y(ctx) { it.swipe(0.2f, 0.5f, 0.8f, 0.5f) }
            Command.TAP_CENTER -> a11y(ctx) { it.tap(0.5f, 0.5f) }
        }
    }

    private fun audio(ctx: Context): AudioManager =
        ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun mediaKey(ctx: Context, code: Int) {
        val am = audio(ctx)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun brightness(ctx: Context, delta: Int) {
        if (!Settings.System.canWrite(ctx)) {
            toast(ctx, "Parlaklık için 'Sistem ayarlarını değiştir' izni gerekli")
            return
        }
        val cr = ctx.contentResolver
        Settings.System.putInt(
            cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        )
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (cur + delta).coerceIn(8, 255))
    }
}
