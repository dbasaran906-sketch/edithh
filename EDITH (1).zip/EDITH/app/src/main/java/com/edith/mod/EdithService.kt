package com.edith.mod

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class EdithService : LifecycleService() {

    private val main = Handler(Looper.getMainLooper())
    private var landmarker: HandLandmarker? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var executor: ExecutorService? = null
    private var overlay: GlowOverlay? = null
    private var started = false

    // Hareket takibi (yalnızca analiz iş parçacığında kullanılır)
    private var candidate: Gesture? = null
    private var candidateSince = 0L
    private var miss = 0
    private var fired = false

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        overlay = GlowOverlay(this)
        executor = Executors.newSingleThreadExecutor()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (started) return START_NOT_STICKY
        started = true

        startAsForeground()

        if (!initLandmarker()) {
            CommandExecutor.toast(this, "EDITH: el modeli yüklenemedi")
            stopSelf()
            return START_NOT_STICKY
        }
        startCamera()
        EdithState.running.value = true
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        return super.onBind(intent)
    }

    // ---------------------------------------------------------------- ön plan

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "EDITH", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    private fun startAsForeground() {
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, EdithService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_edith)
            .setContentTitle("EDITH aktif")
            .setContentText("Ön kamera hareketleri dinleniyor")
            .setContentIntent(openPi)
            .addAction(0, "Durdur", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= 30) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------ model/kamera

    private fun initLandmarker(): Boolean {
        return try {
            val base = BaseOptions.builder().setModelAssetPath(MODEL_FILE).build()
            val opts = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setRunningMode(RunningMode.IMAGE)
                .build()
            landmarker = HandLandmarker.createFromOptions(this, opts)
            true
        } catch (t: Throwable) {
            false
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider

                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(640, 480))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor!!) { proxy -> analyze(proxy) }

                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                CommandExecutor.toast(this, "EDITH: ön kamera açılamadı")
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val lm = landmarker ?: return
            val raw = proxy.toBitmap()
            val rot = proxy.imageInfo.rotationDegrees
            val bmp: Bitmap = if (rot != 0) {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            } else {
                raw
            }
            val result = lm.detect(BitmapImageBuilder(bmp).build())
            val hand = result.landmarks().firstOrNull()
            val g = if (hand != null) {
                GestureClassifier.classify(hand, bmp.width.toFloat() / bmp.height.toFloat(), Prefs.sensitivity)
            } else {
                null
            }
            onFrame(g)
        } catch (t: Throwable) {
            // tek kare hatası önemsiz
        } finally {
            proxy.close()
        }
    }

    // ------------------------------------------------------------ hareket takibi

    private fun onFrame(g: Gesture?) {
        val now = SystemClock.elapsedRealtime()

        if (g == candidate) {
            miss = 0
        } else {
            miss++
            if (candidate == null || miss >= 3) {
                candidate = g
                candidateSince = now
                miss = 0
                fired = false
                EdithState.holdProgress.value = 0f
            }
        }

        val c = candidate
        EdithState.liveGesture.value = c
        if (c == null) {
            EdithState.holdProgress.value = 0f
            return
        }
        if (fired) return

        val hold = Prefs.holdMs
        val held = now - candidateSince
        EdithState.holdProgress.value = (held.toFloat() / hold).coerceIn(0f, 1f)
        if (held >= hold) {
            fired = true
            EdithState.holdProgress.value = 1f
            main.post { trigger(c) }
        }
    }

    private fun trigger(g: Gesture) {
        val cmd = Prefs.getCommand(g)
        if (cmd == Command.NONE) return

        val text = "${g.emoji}  ${g.label}  ›  ${commandText(g, cmd)}"
        EdithState.lastAction.value = text

        if (Prefs.vibrate) buzz()
        if (Prefs.sound) chime()
        if (Prefs.glow) overlay?.show(text)

        CommandExecutor.execute(this, g, cmd)
    }

    private fun commandText(g: Gesture, cmd: Command): String {
        if (cmd == Command.OPEN_APP) {
            val l = Prefs.getAppLabel(g)
            if (l.isNotBlank()) return l
        }
        return cmd.label
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            v.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
            // titreşim yoksa geç
        }
    }

    private fun chime() {
        try {
            val t = ToneGenerator(AudioManager.STREAM_SYSTEM, 35)
            t.startTone(ToneGenerator.TONE_PROP_ACK, 120)
            main.postDelayed({ t.release() }, 400)
        } catch (e: Exception) {
            // ses yoksa geç
        }
    }

    // ----------------------------------------------------------------- bitiş

    override fun onDestroy() {
        try {
            cameraProvider?.unbindAll()
        } catch (e: Exception) {
            // yok say
        }
        executor?.shutdown()
        try {
            executor?.awaitTermination(500, TimeUnit.MILLISECONDS)
        } catch (e: Exception) {
            // yok say
        }
        try {
            landmarker?.close()
        } catch (t: Throwable) {
            // yok say
        }
        landmarker = null
        overlay?.dismiss()
        EdithState.running.value = false
        EdithState.liveGesture.value = null
        EdithState.holdProgress.value = 0f
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.edith.mod.STOP"
        private const val CHANNEL_ID = "edith_channel"
        private const val NOTIF_ID = 1
        private const val MODEL_FILE = "hand_landmarker.task"
    }
}
