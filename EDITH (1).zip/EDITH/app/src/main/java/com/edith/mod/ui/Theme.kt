package com.edith.mod.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object EdithColors {
    val Silver = Color(0xFFE6E6E6)
    val Steel = Color(0xFF9A9A9A)
    val Dim = Color(0xFF6B6B6B)
    val Line = Color(0x26FFFFFF)
    val CardBg = Color(0xE6070707)
}

private val EdithScheme = darkColorScheme(
    primary = Color.White,
    onPrimary = Color.Black,
    secondary = EdithColors.Silver,
    onSecondary = Color.Black,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color(0xFF0A0A0A),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF141414),
    onSurfaceVariant = EdithColors.Steel,
    outline = EdithColors.Line
)

@Composable
fun EdithTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = EdithScheme,
        typography = Typography(),
        content = content
    )
}
