package com.edith.mod.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EdithCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    var m = modifier
        .fillMaxWidth()
        .clip(shape)
        .background(EdithColors.CardBg)
        .border(1.dp, EdithColors.Line, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text,
        color = EdithColors.Steel,
        fontSize = 11.sp,
        letterSpacing = 3.sp,
        fontWeight = FontWeight.Medium
    )
}

@Composable
fun ScreenTitle(title: String, subtitle: String) {
    Column(Modifier.padding(top = 20.dp)) {
        Text(
            title,
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraLight,
            letterSpacing = 8.sp
        )
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = EdithColors.Steel, fontSize = 13.sp)
    }
}

@Composable
fun PowerButton(active: Boolean, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "power")
    val angle by inf.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart),
        label = "angle"
    )
    val glow by animateFloatAsState(if (active) 1f else 0f, tween(600), label = "glow")

    Box(
        Modifier.size(176.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(176.dp)) {
            val c = center
            val radius = size.minDimension / 2f
            val a = if (active) angle else 0f

            rotate(a, c) {
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(
                            Color.White, Color(0xFF3A3A3A), Color.White,
                            Color(0xFF3A3A3A), Color.White
                        ),
                        c
                    ),
                    radius = radius - 2.dp.toPx(),
                    center = c,
                    style = Stroke(3.dp.toPx())
                )
            }
            drawCircle(color = Color.White.copy(alpha = 0.10f * glow), radius = radius, center = c)

            val inner = radius - 14.dp.toPx()
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFF2A2A2A), Color(0xFF050505)),
                    center = c,
                    radius = inner
                ),
                radius = inner,
                center = c
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.15f),
                radius = inner,
                center = c,
                style = Stroke(1.dp.toPx())
            )

            // Güç simgesi
            val gr = 30.dp.toPx()
            val col = if (active) Color.White else Color(0xFF9A9A9A)
            drawArc(
                color = col,
                startAngle = -60f,
                sweepAngle = 300f,
                useCenter = false,
                topLeft = Offset(c.x - gr, c.y - gr),
                size = Size(gr * 2f, gr * 2f),
                style = Stroke(4.dp.toPx(), cap = StrokeCap.Round)
            )
            drawLine(
                color = col,
                start = Offset(c.x, c.y - gr - 6.dp.toPx()),
                end = Offset(c.x, c.y - 4.dp.toPx()),
                strokeWidth = 4.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf("ANA", "HAREKETLER", "AYARLAR")
    Column(Modifier.fillMaxWidth().background(Color(0xF2000000))) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(EdithColors.Line))
        Row(Modifier.fillMaxWidth()) {
            items.forEachIndexed { i, label ->
                val sel = i == selected
                Column(
                    Modifier
                        .weight(1f)
                        .clickable { onSelect(i) }
                        .padding(vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        label,
                        color = if (sel) Color.White else EdithColors.Dim,
                        fontSize = 12.sp,
                        letterSpacing = 2.sp,
                        fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal
                    )
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier
                            .width(if (sel) 24.dp else 0.dp)
                            .height(2.dp)
                            .background(Color.White)
                    )
                }
            }
        }
    }
}
