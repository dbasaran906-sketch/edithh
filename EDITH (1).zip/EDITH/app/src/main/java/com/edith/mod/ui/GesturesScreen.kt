package com.edith.mod.ui

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.edith.mod.Command
import com.edith.mod.Gesture
import com.edith.mod.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun GesturesScreen() {
    var version by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Gesture?>(null) }
    var pickingApp by remember { mutableStateOf<Gesture?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenTitle("HAREKETLER", "Dokun ve o harekete ne olacağını seç")

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 18.dp)
        ) {
            items(Gesture.values().toList()) { g ->
                val cmd = remember(version) { Prefs.getCommand(g) }
                val appLabel = remember(version) { Prefs.getAppLabel(g) }
                val summary = when {
                    cmd == Command.OPEN_APP && appLabel.isNotBlank() -> "Uygulama: $appLabel"
                    cmd == Command.OPEN_APP -> "Uygulama seçilmedi, dokun"
                    else -> cmd.label
                }
                EdithCard(onClick = { editing = g }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF111111))
                                .border(1.dp, EdithColors.Line, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(g.emoji, fontSize = 24.sp)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                g.label,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(summary, color = EdithColors.Steel, fontSize = 13.sp)
                        }
                        Text("›", color = EdithColors.Steel, fontSize = 24.sp)
                    }
                }
            }
        }
    }

    editing?.let { g ->
        CommandDialog(
            g = g,
            current = Prefs.getCommand(g),
            onDismiss = { editing = null },
            onPick = { c ->
                Prefs.setCommand(g, c)
                editing = null
                if (c == Command.OPEN_APP) pickingApp = g
                version++
            }
        )
    }

    pickingApp?.let { g ->
        AppDialog(
            onDismiss = { pickingApp = null },
            onPick = { pkg, label ->
                Prefs.setApp(g, pkg, label)
                pickingApp = null
                version++
            }
        )
    }
}

@Composable
private fun CommandDialog(
    g: Gesture,
    current: Command,
    onDismiss: () -> Unit,
    onPick: (Command) -> Unit
) {
    val groups = remember { Command.values().toList().groupBy { it.category } }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF070707),
            border = BorderStroke(1.dp, EdithColors.Line)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text(
                    "${g.emoji}  ${g.label}",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Light
                )
                Text(g.hint, color = EdithColors.Steel, fontSize = 12.sp)
                Spacer(Modifier.padding(6.dp))
                LazyColumn(Modifier.heightIn(max = 460.dp)) {
                    groups.forEach { (cat, list) ->
                        item {
                            Text(
                                cat.uppercase(),
                                color = EdithColors.Steel,
                                fontSize = 11.sp,
                                letterSpacing = 3.sp,
                                modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)
                            )
                        }
                        items(list) { c ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { onPick(c) }
                                    .padding(vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    c.label + if (c.needsAccessibility) "  ·  erişilebilirlik" else "",
                                    color = if (c == current) Color.White else EdithColors.Silver,
                                    fontSize = 15.sp,
                                    fontWeight = if (c == current) FontWeight.SemiBold else FontWeight.Normal,
                                    modifier = Modifier.weight(1f)
                                )
                                if (c == current) Text("●", color = Color.White, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppDialog(onDismiss: () -> Unit, onPick: (String, String) -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(intent, 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF070707),
            border = BorderStroke(1.dp, EdithColors.Line)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Uygulama seç", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.padding(6.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("Ara") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.padding(4.dp))
                val list = apps
                if (list == null) {
                    Text("Yükleniyor…", color = EdithColors.Steel, fontSize = 14.sp)
                } else {
                    val filtered = list.filter { it.first.contains(query, ignoreCase = true) }
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(filtered) { (label, pkg) ->
                            Text(
                                label,
                                color = Color.White,
                                fontSize = 15.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onPick(pkg, label) }
                                    .padding(vertical = 12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
