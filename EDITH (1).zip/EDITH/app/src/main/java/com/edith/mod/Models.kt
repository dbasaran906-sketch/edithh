package com.edith.mod

enum class Gesture(val label: String, val emoji: String, val hint: String) {
    FIST("Yumruk", "✊", "Tüm parmaklar kapalı"),
    ONE("1 Parmak", "☝️", "Sadece işaret parmağı açık"),
    TWO("2 Parmak", "✌️", "İşaret + orta parmak"),
    THREE("3 Parmak", "③", "İşaret + orta + yüzük parmağı"),
    FOUR("4 Parmak", "④", "Başparmak kapalı, 4 parmak açık"),
    FIVE("Açık El", "🖐️", "5 parmak da açık"),
    THUMB_UP("Başparmak Yukarı", "👍", "Yumruk + başparmak yukarı"),
    THUMB_DOWN("Başparmak Aşağı", "👎", "Yumruk + başparmak aşağı"),
    OK("OK", "👌", "Başparmak ve işaret parmağı birleşik"),
    ROCK("Rock", "🤘", "İşaret + küçük parmak"),
    CALL("Telefon", "🤙", "Başparmak + küçük parmak"),
    LOVE("Seni Seviyorum", "🤟", "Başparmak + işaret + küçük parmak")
}

enum class Command(
    val label: String,
    val category: String,
    val needsAccessibility: Boolean = false
) {
    NONE("Hiçbir şey yapma", "Genel"),

    OPEN_APP("Uygulama aç (sen seç)", "Uygulamalar"),
    OPEN_CAMERA("Kamerayı aç", "Uygulamalar"),
    OPEN_DIALER("Telefonu aç", "Uygulamalar"),
    OPEN_CLOCK("Saat / Alarm", "Uygulamalar"),
    OPEN_SETTINGS("Ayarları aç", "Uygulamalar"),
    OPEN_ASSISTANT("Sesli asistan", "Uygulamalar"),
    OPEN_GOOGLE("Google'ı aç", "Uygulamalar"),
    OPEN_INTERNET_PANEL("İnternet / Wi-Fi paneli", "Uygulamalar"),

    FLASHLIGHT("Feneri aç / kapat", "Donanım"),

    VOLUME_UP("Sesi artır", "Ses ve Parlaklık"),
    VOLUME_DOWN("Sesi azalt", "Ses ve Parlaklık"),
    MUTE("Sesi kapat / aç", "Ses ve Parlaklık"),
    BRIGHTNESS_UP("Parlaklığı artır", "Ses ve Parlaklık"),
    BRIGHTNESS_DOWN("Parlaklığı azalt", "Ses ve Parlaklık"),

    MEDIA_PLAY_PAUSE("Oynat / Durdur", "Müzik"),
    MEDIA_NEXT("Sonraki şarkı", "Müzik"),
    MEDIA_PREVIOUS("Önceki şarkı", "Müzik"),

    GO_HOME("Ana ekran", "Sistem", true),
    GO_BACK("Geri", "Sistem", true),
    RECENTS("Son uygulamalar", "Sistem", true),
    NOTIFICATIONS("Bildirimleri aç", "Sistem", true),
    QUICK_SETTINGS("Hızlı ayarlar", "Sistem", true),
    LOCK_SCREEN("Ekranı kilitle", "Sistem", true),
    SCREENSHOT("Ekran görüntüsü", "Sistem", true),
    POWER_MENU("Güç menüsü", "Sistem", true),

    SCROLL_DOWN("Aşağı kaydır", "Dokunma", true),
    SCROLL_UP("Yukarı kaydır", "Dokunma", true),
    SWIPE_LEFT("Sola kaydır", "Dokunma", true),
    SWIPE_RIGHT("Sağa kaydır", "Dokunma", true),
    TAP_CENTER("Ekranın ortasına dokun", "Dokunma", true)
}
