package com.edith.mod

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/** Hareket algılanınca ekranın üstünde kısa süre görünen şık bilgi kapsülü. */
class GlowOverlay(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: TextView? = null
    private var hideTask: Runnable? = null

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun show(text: String) {
        if (!Settings.canDrawOverlays(ctx)) return
        dismiss()

        val tv = TextView(ctx).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 15f
            letterSpacing = 0.08f
            setPadding(dp(22), dp(12), dp(22), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(30).toFloat()
                setColor(0xF2000000.toInt())
                setStroke(dp(1), 0xAAFFFFFF.toInt())
            }
            alpha = 0f
            scaleX = 0.9f
            scaleY = 0.9f
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(64)
        }

        try {
            wm.addView(tv, lp)
        } catch (e: Exception) {
            return
        }
        view = tv
        tv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()

        val task = Runnable {
            tv.animate().alpha(0f).setDuration(300).withEndAction { remove(tv) }.start()
        }
        hideTask = task
        handler.postDelayed(task, 1200)
    }

    private fun remove(tv: TextView) {
        try {
            wm.removeView(tv)
        } catch (e: Exception) {
            // zaten kaldırılmış
        }
        if (view === tv) view = null
    }

    fun dismiss() {
        hideTask?.let { handler.removeCallbacks(it) }
        hideTask = null
        view?.let { remove(it) }
        view = null
    }
}
