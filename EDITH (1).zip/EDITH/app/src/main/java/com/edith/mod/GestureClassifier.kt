package com.edith.mod

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * 21 el noktasından hareketi bulur. Kusursuz poz beklemez:
 * oranlara bakar, [sens] yükseldikçe daha toleranslı olur.
 */
object GestureClassifier {

    fun classify(l: List<NormalizedLandmark>, aspect: Float, sens: Float): Gesture? {
        if (l.size < 21) return null

        fun dist(i: Int, j: Int): Float {
            val dx = (l[i].x() - l[j].x()) * aspect
            val dy = l[i].y() - l[j].y()
            return sqrt(dx * dx + dy * dy)
        }

        val palm = dist(0, 9).coerceAtLeast(0.0001f)

        // Parmak açık mı: uç noktası bileğe, kök noktasından ne kadar uzak
        val fingerThr = 1.75f - 0.45f * sens
        fun extended(tip: Int, mcp: Int): Boolean =
            dist(tip, 0) / dist(mcp, 0).coerceAtLeast(0.0001f) > fingerThr

        val index = extended(8, 5)
        val middle = extended(12, 9)
        val ring = extended(16, 13)
        val pinky = extended(20, 17)

        val thumbThr = 1.0f - 0.3f * sens
        val thumb = dist(4, 9) / palm > thumbThr && dist(4, 5) / palm > 0.45f

        val count = listOf(index, middle, ring, pinky).count { it }

        // OK: başparmak ucu ile işaret ucu birleşik, diğer parmaklardan en az ikisi açık
        val pinch = dist(4, 8) / palm < 0.40f + 0.2f * sens
        val othersOpen = listOf(middle, ring, pinky).count { it }
        if (pinch && othersOpen >= 2) return Gesture.OK

        return when {
            !thumb && count == 0 -> Gesture.FIST
            thumb && count == 0 -> {
                val rise = (l[2].y() - l[4].y()) / palm
                when {
                    rise > 0.4f -> Gesture.THUMB_UP
                    rise < -0.4f -> Gesture.THUMB_DOWN
                    else -> null
                }
            }
            index && !middle && !ring && !pinky -> Gesture.ONE
            index && middle && !ring && !pinky -> Gesture.TWO
            index && middle && ring && !pinky -> Gesture.THREE
            count == 4 && !thumb -> Gesture.FOUR
            count == 4 && thumb -> Gesture.FIVE
            !thumb && index && pinky && !middle && !ring -> Gesture.ROCK
            thumb && pinky && count == 1 -> Gesture.CALL
            thumb && index && pinky && !middle && !ring -> Gesture.LOVE
            else -> null
        }
    }

    @Suppress("unused")
    private fun absf(v: Float) = abs(v)
}
