package com.edith.mod

import kotlinx.coroutines.flow.MutableStateFlow

/** Servis ile arayüz arasındaki canlı durum. */
object EdithState {
    val running = MutableStateFlow(false)
    val liveGesture = MutableStateFlow<Gesture?>(null)
    val holdProgress = MutableStateFlow(0f)
    val lastAction = MutableStateFlow("")
}
